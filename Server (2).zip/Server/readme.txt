1. npm init
        description:node restful api
        keywords : node restful api
        auther: name
2. npm install --save express
3. node server.js