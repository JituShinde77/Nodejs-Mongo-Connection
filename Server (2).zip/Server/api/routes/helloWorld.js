const express = require('express');
const router = express.Router();

router.get('/', (req, res, next)=>{
    res.status(200).json({
        json:"Hello World"//[{"name":"Messi", "goals":8},{"name":"Ronaldo", "goals":22},{"name":"Costa", "goals":20},{"name":"Neymar", "goals":13},{"name":"Arabi", "goals":6},{"name":"Bale", "goals":3},{"name":"Toquero", "goals":0}]
    });
});

router.post('/', (req, res, next)=>{
    // const book ={
    //     id = req.body.id
    // };
    res.status(200).json({
        message: "Hello",
        //bookid : id
      
    });
});


module.exports = router;